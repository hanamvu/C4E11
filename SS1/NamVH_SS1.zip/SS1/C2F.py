celcius=input("Enter the temperature in Celsius? ")
print(celcius," (C) = ",32+1.8*float(celcius), " (F)")
