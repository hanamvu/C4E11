from turtle import *
shape("turtle")
color("green")
#pencolor("violet")
speed(0)

begin_fill()
circle(100)
end_fill()
