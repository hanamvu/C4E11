r=input("Radius? ")
print ("Area = ",3.14*int(r)**2)
