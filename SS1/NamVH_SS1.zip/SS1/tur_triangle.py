from turtle import *
shape("turtle")
speed(0)
for i in range (3) :
    forward(100)
    left(120)
