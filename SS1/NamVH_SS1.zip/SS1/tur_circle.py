from turtle import *
shape("turtle")
color("green")
#pencolor("violet")
speed(0)
for i in range(6):
    #begin_fill()
    circle(100)
    #end_fill()
    left(60)
    
